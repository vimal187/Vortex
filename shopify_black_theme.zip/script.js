function buyNow() {
    alert('Product added to cart! Checkout coming soon.');
}