function buyNow() {
    alert('Thank you for your purchase!');
}